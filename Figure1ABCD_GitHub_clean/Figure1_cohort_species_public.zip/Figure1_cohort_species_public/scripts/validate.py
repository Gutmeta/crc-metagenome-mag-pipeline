#!/usr/bin/env python3
"""Validate cohort species profiles and minimal analysis-group labels."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = pd.read_csv(ROOT / 'MANIFEST.tsv', sep='\t')
    if manifest.file.duplicated().any():
        raise ValueError('Duplicate manifest entries')
    expected_files = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob('*')
        if path.is_file() and path.name != 'MANIFEST.tsv'
        and '__pycache__' not in path.parts
    }
    if set(manifest.file) != expected_files:
        raise ValueError('Manifest file inventory mismatch')
    for row in manifest.itertuples():
        path = ROOT / row.file
        if not path.is_file() or path.stat().st_size != row.bytes or sha256(path) != row.sha256:
            raise ValueError(f'Checksum mismatch: {row.file}')
    registry = pd.read_csv(ROOT / 'COHORT_TABLES.tsv', sep='\t', keep_default_na=False)
    arms = pd.read_csv(ROOT / 'ANALYSIS_GROUP_COUNTS.tsv', sep='\t', keep_default_na=False)
    if len(registry) != 20 or registry.cohort_id.duplicated().any() or registry.study_code.duplicated().any():
        raise ValueError('Expected 20 independent studies')
    if not set(arms.cohort_id) <= set(registry.cohort_id) or arms[['cohort_id', 'disease']].duplicated().any():
        raise ValueError('Invalid comparison inventory')
    workbook = ROOT / 'COHORT_TABLES.xlsx'
    for sheet, table in [('Cohort tables', registry), ('Analysis group counts', arms)]:
        excel_table = pd.read_excel(workbook, sheet_name=sheet, keep_default_na=False)
        pd.testing.assert_frame_equal(excel_table, table, check_dtype=False)
    total_samples = 0
    total_rows = 0
    for row in registry.itertuples():
        profile_path = ROOT / row.profile_file
        group_path = ROOT / row.sample_groups_file
        if sha256(profile_path) != row.profile_sha256 or sha256(group_path) != row.sample_groups_sha256:
            raise ValueError(f'Data file hash mismatch: {row.cohort_id}')
        profile = pd.read_csv(profile_path, sep='\t', dtype={'sample_alias': str, 'clade_name': str})
        if profile.columns.tolist() != ['sample_alias', 'clade_name', 'rel_abund']:
            raise ValueError('Unexpected profile fields')
        if not profile.sample_alias.str.fullmatch('SMP_[0-9a-f]{20}').all():
            raise ValueError('Unexpected specimen identifier')
        if not profile.clade_name.str.startswith('s__').all():
            raise ValueError('Non-species rank found')
        if not np.isfinite(profile.rel_abund).all() or profile.rel_abund.lt(0).any():
            raise ValueError('Invalid abundance value')
        groups = pd.read_csv(group_path, sep='\t', dtype={'sample_id': str})
        allowed = {'sample_id', 'CRA', 'CRC', 'CRC_CRA', 'IBD', 'IBS'}
        if 'sample_id' not in groups.columns or not set(groups.columns) <= allowed or groups.sample_id.duplicated().any():
            raise ValueError('Unexpected grouping fields or duplicate identifiers')
        if set(profile.sample_alias) != set(groups.sample_id):
            raise ValueError('Profile/group specimen mismatch')
        for column in set(groups.columns) - {'sample_id'}:
            if not set(groups[column]) <= {'case', 'control', 'not_in_comparison'}:
                raise ValueError('Unexpected comparison label')
        for arm in arms[arms.cohort_id.eq(row.cohort_id)].itertuples():
            if arm.profile_file != row.profile_file or arm.sample_groups_file != row.sample_groups_file:
                raise ValueError('Comparison file path mismatch')
            counts = groups[arm.disease].value_counts()
            if counts.get('case', 0) != arm.case_samples or counts.get('control', 0) != arm.control_samples:
                raise ValueError('Analysis group counts mismatch')
        if len(profile) != row.profile_rows or profile.sample_alias.nunique() != row.profile_samples or profile.clade_name.nunique() != row.profile_species:
            raise ValueError('Profile dimensions mismatch')
        total_samples += profile.sample_alias.nunique()
        total_rows += len(profile)
    summary = json.loads((ROOT / 'VALIDATION_SUMMARY.json').read_text())
    observed = {
        'cohorts': len(registry),
        'profile_files': len(list((ROOT / 'profiles').glob('*.species.tsv.gz'))),
        'sample_group_files': len(list((ROOT / 'sample_groups').glob('*.groups.tsv'))),
        'profile_samples': total_samples,
        'profile_rows': total_rows,
        'analysis_comparisons': len(arms),
    }
    for field, value in observed.items():
        if summary[field] != value:
            raise ValueError(f'Validation summary mismatch: {field}')
    ibs = arms[arms.disease.eq('IBS')]
    if len(ibs) != 1 or ibs.iloc[0].cohort_id != summary['IBS']['cohort_id'] or int(ibs.iloc[0].case_samples) != summary['IBS']['case_samples'] or int(ibs.iloc[0].control_samples) != summary['IBS']['control_samples']:
        raise ValueError('IBS summary mismatch')
    print(f'Validated {len(registry)} studies; {total_samples} profiled specimens; {total_rows} abundance records.')


if __name__ == '__main__':
    main()
