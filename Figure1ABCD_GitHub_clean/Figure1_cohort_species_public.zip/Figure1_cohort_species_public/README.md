# Figure 1 cohort species abundance data

This companion dataset provides MetaPhlAn 4 species abundance profiles and minimal case/control labels for the Figure 1 analyses. It covers **20 independent studies**: 10 colorectal studies, 9 inflammatory bowel disease (IBD) studies, and the Mars_2020 irritable bowel syndrome (IBS) study. A colorectal study can contribute both colorectal adenoma (CRA) and colorectal cancer (CRC) comparisons without becoming two independent studies.

The dataset contains **6,264 profiled specimens and 934,240 abundance records**. Specimens are not necessarily distinct participants: some studies include repeated visits or longitudinal samples. Controls can also appear in more than one disease comparison, so comparison counts must not be added to estimate the number of independent participants. The IBS comparison includes **323 case specimens and 151 control specimens** from Mars_2020.

## Contents

- `profiles/`: 20 compressed long-format species relative-abundance tables.
- `sample_groups/`: 20 tables containing pseudonymized specimen identifiers and the applicable comparison labels.
- `COHORT_TABLES.tsv` and `COHORT_TABLES.xlsx`: study identifiers, public project accessions where available, source URLs, file paths, dimensions, and SHA-256 digests.
- `ANALYSIS_GROUP_COUNTS.tsv`: case/control specimen counts for each disease comparison, including combined CRC/CRA.
- `VALIDATION_SUMMARY.json`: dataset dimensions and the checks performed by the supplied validator.
- `MANIFEST.tsv`: file sizes and SHA-256 digests for the distributed files.
- `scripts/validate.py`: integrity, schema, identifier, abundance, and comparison-count checks.
- `scripts/export_matrix.py`: conversion of a cohort table into a species-by-specimen matrix.

## Data scope

The tables contain species profiles for specimens eligible for the disease comparisons. They represent the inputs **before the Figure 1 species prevalence, mean-abundance, and model-based selection filters**. No additional species filtering, Top-300 selection, numerical rounding, or abundance renormalization is applied to these companion tables. The figure's selected species sets and detectable species backgrounds are therefore subsets derived from these inputs, rather than the full contents of the profile tables.

The values are microbial species relative abundances on the source-export scale. They are not raw sequencing reads or absolute organism counts. Preserve the supplied scale when reusing the data.

The grouping tables provide pseudonymized identifiers and case/control labels. Participant-level identifiers, demographic fields, visit dates, geographic fields, and free-text metadata are not included. The identifiers connect profile records to grouping records within this dataset; they do not identify distinct participants across repeated specimens.

## Table schema

Each `profiles/*.species.tsv.gz` file contains:

| Column | Description |
|---|---|
| `sample_alias` | Pseudonymized specimen identifier; matches `sample_id` in its grouping table. |
| `clade_name` | Species identifier beginning with `s__`, including source species-level genome bin (SGB) names. |
| `rel_abund` | Relative-abundance value on the source-export scale. |

Each `sample_groups/*.groups.tsv` file contains `sample_id` and one or more of `CRA`, `CRC`, `CRC_CRA`, `IBD`, and `IBS`. A comparison label is `case`, `control`, or `not_in_comparison`. For example, a CRC specimen may be a case for CRC and CRC_CRA while having `not_in_comparison` for CRA.

`COHORT_TABLES.tsv` contains one row per study. `profile_samples`, `profile_rows`, and `profile_species` describe the distributed table. `profile_sha256` and `sample_groups_sha256` identify the corresponding distributed files. `source_export_sha256` identifies the public source export used for the species data; its checksum differs from the pseudonymized, eligible-specimen table when those files have different contents. `ANALYSIS_GROUP_COUNTS.tsv` contains one row per study and disease comparison; its counts refer to specimens, not necessarily distinct participants.

## Sources and licensing

Public MetaLog source URLs and established project accessions are provided in `COHORT_TABLES.tsv`. Mars_2020 is identified by its study code and public MetaLog URL; its project accession is left blank. URLs containing `latest` may change over time, so use the recorded digests to identify the distributed profiles and source exports.

Source datasets remain subject to their providers' licenses and redistribution terms. Any license for the accompanying figure code does not replace or expand those source-data terms. Consult the source repositories and study records when reusing or redistributing these profiles.

## Validation and use

Install pandas, NumPy, and openpyxl, then validate the dataset from this directory:

```bash
python3 scripts/validate.py
```

The validator checks file digests, allowed fields, pseudonymized specimen identifiers, species rank, finite nonnegative abundance values, profile/group agreement, cohort dimensions, comparison counts, and agreement between the TSV and Excel registry tables. These checks establish the integrity of the supplied dataset; they do not train or evaluate the Figure 1 models.

To create a species-by-specimen matrix:

```bash
python3 scripts/export_matrix.py --cohort PRJEB7774 --output ../PRJEB7774_species_matrix.tsv.gz
```

The matrix converter fills absent specimen-species pairs with zero and sums repeated pairs. It performs no filtering or renormalization. Keep this folder's contents together when sharing the companion dataset.
